package ir.hoseinnama.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 9, 11)
    private val red = Color.rgb(210, 15, 28)
    private val gold = Color.rgb(244, 190, 45)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(18), dp(14), dp(12))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        content.addView(label("حسین‌نما", 30, gold, true, Gravity.CENTER))
        content.addView(label("گالری فیلم‌ها و محتوای مذهبی", 14, white, false, Gravity.CENTER))
        content.addView(space(16))

        val search = EditText(this).apply {
            hint = "جست‌وجو در فیلم‌ها..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            textSize = 16f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.rgb(38, 34, 36), dp(24), red, dp(1))
        }
        content.addView(search, matchHeight(52))
        content.addView(space(14))

        content.addView(label("دسته‌بندی‌ها", 20, gold, true, Gravity.RIGHT))
        val categories = listOf("همه ویدیوها", "نوحه‌ها", "کربلا", "روضه‌ها", "محرم", "مداحی")
        val catRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        categories.forEach { name ->
            val b = Button(this).apply {
                text = name
                textSize = 11f
                setTextColor(white)
                isAllCaps = false
                background = rounded(Color.rgb(45, 20, 24), dp(18), red, dp(1))
                setOnClickListener { Toast.makeText(this@MainActivity, "دسته $name انتخاب شد", Toast.LENGTH_SHORT).show() }
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            catRow.addView(b, lp)
        }
        content.addView(catRow)
        content.addView(space(18))

        content.addView(label("تازه‌ترین ویدیوها", 21, gold, true, Gravity.RIGHT))
        val samples = listOf(
            "نوحه زیبا | حسین ستوده و محمدرضا صادقیان" to "۲۲:۴۵",
            "روضه جانسوز حضرت اباعبدالله الحسین" to "۱۵:۳۲",
            "مداحی ویژه محرم" to "۲۰:۱۷",
            "داستان کربلا" to "۱۸:۲۰"
        )
        samples.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.rgb(25, 22, 24), dp(12), red, dp(1))
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }
            val thumb = FrameLayout(this).apply {
                background = rounded(Color.rgb(70, 12, 20), dp(8), red, dp(1))
                addView(label("▶", 34, white, true, Gravity.CENTER),
                    FrameLayout.LayoutParams(-1, -1))
                addView(label(item.second, 12, white, true, Gravity.BOTTOM or Gravity.LEFT).apply {
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                }, FrameLayout.LayoutParams(-1, -1))
            }
            card.addView(thumb, matchHeight(116))
            card.addView(space(8))
            card.addView(label(item.first, 15, white, true, Gravity.RIGHT))
            card.setOnClickListener {
                Toast.makeText(this, "برای پخش، لینک ویدیوی واقعی را اضافه کنید.", Toast.LENGTH_LONG).show()
            }
            val params = LinearLayout.LayoutParams(-1, dp(180))
            params.bottomMargin = dp(12)
            content.addView(card, params)
        }

        content.addView(space(8))
        content.addView(label("خانه     دسته‌بندی‌ها     علاقه‌مندی‌ها     دانلودها     پروفایل", 14, white, true, Gravity.CENTER))
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean, gravity: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            this.gravity = gravity
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearHeight(dp(h))
    }

    private fun matchHeight(h: Int) = LinearLayout.LayoutParams(-1, dp(h))
    private fun LinearHeight(h: Int) = LinearLayout.LayoutParams(-1, h)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int, strokeWidth: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(strokeWidth, stroke)
        }
}
